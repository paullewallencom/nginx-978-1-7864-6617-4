## $5 Tech Unlocked 2021!
[Buy and download this Book for only $5 on PacktPub.com](https://www.packtpub.com/product/nginx-cookbook/9781786466174)
-----
*If you have read this book, please leave a review on [Amazon.com](https://www.amazon.com/gp/product/1786466171).     Potential readers can then use your unbiased opinion to help them make purchase decisions. Thank you. The $5 campaign         runs from __December 15th 2020__ to __January 13th 2021.__*

# NGINX Cookbook
This is the code repository for [NGINX Cookbook](https://www.packtpub.com/networking-and-servers/nginx-cookbook?utm_source=github&utm_medium=repository&utm_campaign=9781786466174), published by [Packt](https://www.packtpub.com/?utm_source=github). It contains all the supporting project files necessary to work through the book from start to finish.
## About the Book
This book also focuses on key NGINX features such as back-end SSL certificate verification, IPv6, log aggregation over network, thread pools, support for offloading I/O requests, and much more. This book also covers advanced topics such as covering bandwidth management, Docker container usage, performance tuning, OpenResty, and the NGINX Plus commercial features.
##Instructions and Navigation
All of the code is organized into folders. Each folder starts with a number followed by the application name. For example, Chapter02.



The code will look like the following:
```
server {
      listen 80;
      server_name server.yourdomain.com; 
      access_log /var/log/nginx/log/host.access.log combined;
         
      location / {
          root /var/www/html;
          index index.html; 
      }
}
```

The following is the list of software you require to go through the recipes covered in this book:

* NGINX
* PHP 7
* Ubuntu/CentOS/RHEL

## Related Products
* [Nginx HTTP Server - Third Edition](https://www.packtpub.com/networking-and-servers/nginx-http-server-third-edition?utm_source=github&utm_medium=repository&utm_campaign=9781785280337)

* [Nginx Troubleshooting](https://www.packtpub.com/networking-and-servers/nginx-troubleshooting?utm_source=github&utm_medium=repository&utm_campaign=9781785288654)

* [NGINX High Performance](https://www.packtpub.com/networking-and-servers/nginx-high-performance?utm_source=github&utm_medium=repository&utm_campaign=9781785281839)


